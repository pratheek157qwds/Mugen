module.exports = {
    client_token: "",
    client_id: "",
    client_prefix: ".",
    mongodb_url: "",
    developers: ["744557711513092098"],
    sharding: true,
    database: false,
    nodes: [
        {
            "password": "youshallnotpass",
            "host": "node.lewdhutao.my.eu.org",
            "port": 80,
            "secure": false
        }
    ]
}