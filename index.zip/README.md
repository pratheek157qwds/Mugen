riffy example music bot source updated by pratheek and added more than 100 commands
